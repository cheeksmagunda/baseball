# Historical MLB DFS Data — Handoff Bundle

A daily-fantasy-baseball historical corpus covering **43 slates** from
**2026-03-25 → 2026-05-07** (regular season). Every slate is the set of
MLB games on a single calendar date that users could draft from on the
"Real Sports" platform.

## What's in this bundle

| File | Format | Rows | Role |
|---|---|---|---|
| `historical.db` | SQLite | 10 tables (~38k rows total) | **Canonical store.** All other files are derived from this. |
| `historical_players.csv` | CSV | 1644 | Per-(slate, player) at-slate features + outcome flags |
| `historical_winning_drafts.csv` | CSV | 2308 | Top-N winning lineups per slate (5 rows each) |
| `historical_slate_results.json` | JSON | 43 envelopes / 551 games | Per-game env signals + final scores |
| `hv_player_game_stats.csv` | CSV | 751 | Box scores for "Highest Value" leaderboard players |
| `historical_player_game_logs.csv` | CSV | 12290 | Trailing 10-game window per player per slate |

The CSV/JSON files are byte-stable derivations of the SQLite store; if
you regenerate them from the DB you should get the same content. Use
the SQLite store for analysis — joins are fast, and the schema is
explicit and typed. The CSV/JSON exports exist for ad-hoc inspection
and tooling that doesn't speak SQL.

## SQLite schema (10 tables)

| Table | Rows | Cols | Role |
|---|---|---|---|
| `slate` | 43 | 7 | One row per slate envelope: date, game_count, season_stage. |
| `slate_game` | 551 | 131 | Per-game env signals **and** post-game outcomes. PK `(slate_date, game_pk, game_number)`. |
| `player_slate` | 1644 | 87 | Per-(slate_date, mlb_id) identity + at-slate inputs (season stats, recent splits, projections). |
| `player_game_log` | 12290 | 21 | Prior-game outcomes per (slate_date, mlb_id, game_date) for the trailing 10-game window. |
| `label_event` | 13319 | 7 | Typed/sourced/dated outcome labels. `label_type` ∈ {real_score, card_boost, drafts, draft_count, injury_status, highest_value, most_popular, most_drafted_3x, winning_lineup_slot, box_score, wpa, transaction}. |
| `player_dim` | 399 | 12 | Per-mlb_id slowly-changing attributes (handedness, birth, debut, physicals, primary position). |
| `venue_dim` | 31 | 18 | Per-venue static dimensions (capacity, surface, roof, elevation, lat/lon, fence distances, HP→CF azimuth). |
| `statcast_pa` | 2983 | 11 | Per-batted-ball Statcast detail (exit velocity, launch angle, x_woba, pitch type, result) for HV games. |
| `batter_pitch_type_woba` | 7511 | 6 | Per-batter, per-pitch-type wOBA crosstab. |
| `player_alias` | 0 | 5 | Side table for HV box-score identity recovery; populated only on demand. |

## CSV / JSON column quick reference

### `historical_players.csv` (34 cols)

```
date, player_name, team, position,
real_score, is_highest_value, is_most_popular, is_most_drafted_3x,
ops_at_slate, iso_at_slate, era_at_slate, whip_at_slate, k9_at_slate,
x_woba, x_ba, x_slg, avg_ev, hard_hit_pct, barrel_pct, max_ev,
x_era, x_woba_against, fb_velo, whiff_pct, chase_pct, fb_ivb, fb_extension,
ops_vs_lhp_at_slate, ops_vs_rhp_at_slate, batting_order_at_slate,
card_boost, drafts, draft_count, injury_status
```

Outcome columns: `real_score`, the three boolean leaderboard flags
(`is_highest_value` / `is_most_popular` / `is_most_drafted_3x`),
`card_boost`, `drafts`, `draft_count`. Everything else is an at-slate
predictor (factual aggregates as of the slate date).

### `historical_winning_drafts.csv` (10 cols)

```
date, winner_rank, slot_index, player_name, team, position,
real_score, slot_mult, card_boost, total_mult
```

5 rows per lineup. Slot multipliers are fixed at `{2.0, 1.8, 1.6, 1.4,
1.2}`. `winner_rank` indexes the top-N winning lineups for a given
slate (rank 1 = the lineup with the highest total points).

### `historical_slate_results.json`

Top-level array of envelopes. Each envelope:

```json
{
  "date": "2026-03-25",
  "game_count": 14,
  "num_brawlers": 142,
  "season_stage": "regular",
  "source": "...",
  "saved_at": "2026-03-26T...",
  "games": [ { ...per-game fields... }, ... ]
}
```

Per-game fields cover three buckets:
- **Identity**: `game_pk`, `home`, `away`, `datetime_utc`, `venue_id`, etc.
- **Pre-game env signals**: starter ERA/WHIP/K9, team OPS, bullpen ERA,
  framing runs, weather (temp/wind/humidity/pressure/air density),
  Vegas (moneyline, O/U, opening lines), park HR factors split by
  batter side, lineup handedness counts, travel/rest, standings, etc.
- **Post-game outcomes**: `home_score`, `away_score`, `winner`, `loser`,
  per-team hits + HR.

### `hv_player_game_stats.csv` (20 cols)

Box-score detail for players who landed on the "Highest Value"
leaderboard for a slate. Identity columns + standard batting/pitching
lines (AB, R, H, HR, RBI, BB, SO, IP, ER, K, decision) + a free-text
`notes` field summarising the performance.

### `historical_player_game_logs.csv` (21 cols)

Per-(slate, player, prior game) stat lines for the trailing 10-game
window. Used to compute recent-form and momentum signals.

## Data sources

All sources are free; no paid API tier is required.

| Source | URL | What we pull |
|---|---|---|
| **MLB Stats API** | `https://statsapi.mlb.com/api/v1` | Schedule, rosters, boxscores, season stats, standings, transactions, team schedules (for travel calc). The primary source. |
| **Baseball Savant** (Statcast) | `https://baseballsavant.mlb.com` | Statcast leaderboards: exit velocity, hard-hit%, barrel%, x_woba/x_ba/x_slg, x_era, fastball velocity/IVB, whiff%, chase%, sprint speed, OAA, bat tracking, catcher framing, park HR factors split L/R. |
| **pybaseball** (bulk Statcast) | `pip install pybaseball` | Per-pitch and per-batted-ball Statcast pulls, cached as parquet. Used for: per-batter pitch-type wOBA, regression flags, GB/FB/LD splits, velocity trends, TTO splits, BvP, recent handedness splits, WPA, in-zone contact%. |
| **Open-Meteo Archive** | `https://archive-api.open-meteo.com` | Historical weather at first-pitch hour: temp, wind speed/direction, humidity, pressure (used to compute air density). |
| **The Odds API** | `https://api.the-odds-api.com` | Closing moneyline + over/under per game (free tier: 500 req/month). |
| **SportsbookReview** (`__NEXT_DATA__` scrape) | `https://www.sportsbookreview.com` | Opening + current Vegas lines per book; used for line-movement signals. |
| **FantasyPros** (HTML scrape) | `https://www.fantasypros.com/mlb/` | DFS projected ownership %, vendor projected DK points. |
| **RotoWire** (HTML scrape) | `https://www.rotowire.com/baseball/daily-lineups.php` | Expected lineups (beat-reporter projections). Used to populate `batting_order_at_slate`. |
| **Real Sports app** (Playwright scrape) | (proprietary platform) | Per-slate leaderboards (HV / MP / 3X), top winning lineups, game results. The outcome side of the corpus — `real_score`, `card_boost`, `drafts`, `is_highest_value`, etc. |

## How the data is collected (high level)

The collection runs out-of-band from the live runtime — i.e. the
historical store is built up day-by-day by an automated daily job, not
by the live serving path.

The pattern is the same for every slate:

1. **Real Sports leaderboard scrape** (Playwright). Captures the day's
   leaderboards (HV / MP / 3X), top-20 winning lineups, and game
   results. Writes the outcome rows and the slate envelope.

2. **Per-game env enrichment**. For each game on the slate, fetch the
   probable starters' season stats, team-level offense/bullpen
   aggregates, opening Vegas line, weather forecast at first-pitch hour,
   park factors, standings as-of-date.

3. **External-data backfills**. A series of idempotent backfill jobs
   pull each external source (MLB API gumbo feed for venue + boxscore +
   bullpen, Savant CSV leaderboards for kinematics + xStats + framing +
   sprint + OAA, bulk Statcast for per-pitch and per-batted-ball
   detail, Open-Meteo for weather, FantasyPros for ownership +
   projections, SportsbookReview for line movement, MLB transactions
   for IL/call-up labels). Each job is keyed/cached so re-runs are
   no-ops.

4. **Outcome + box-score backfill**. Once the slate's games are final,
   a job pulls the official box scores from the MLB API for every
   leaderboard player and writes the game-result rows.

5. **Validation**. A validator confirms each slate has the expected
   row counts in lockstep across the four CSV files and the SQLite
   tables, no duplicate `(date, player_name, team)` rows, all required
   columns populated, and game results matching the captured slate
   envelope.

After step 5 the slate is "ingested" — the SQLite store is canonical
and the CSV/JSON files are refreshed as derivations.

### Some specific point-in-time caveats to be aware of

- **Handedness splits** (`ops_vs_lhp_at_slate` / `ops_vs_rhp_at_slate`)
  are season-totals, not date-cut. The MLB API doesn't honour
  `endDate` on the `statSplits` endpoint, so the value repeats across
  every slate the player appears on within a season.
- **Statcast aggregate columns** (kinematics, xStats, arsenal, sprint,
  bat tracking, OAA) are season-leaderboard snapshots taken at the
  time of the backfill, not per-slate. Re-run the backfill to refresh
  mid-season.
- **`batting_order_at_slate`** is the actual lineup-card slot from the
  post-hoc MLB box score, NOT a pre-game projection. Pinch-hits and
  late-scratch cases are baked in. Players who entered as pinch-hits
  get a blank slot (correct: they didn't start).
- **Standings** at slate_date are exact-as-of-date. Opening-week games
  (~3% of corpus) have NULL standings columns because no W-L existed
  yet.
- **Pitcher Statcast** columns use a 30-pitch minimum. Below the
  threshold the columns are blank rather than emit noisy values.

## Suggested entry points for analysis

Most analysis flows naturally from `slate` → `slate_game` →
`player_slate`. Examples:

```sql
-- All HV winners with their at-slate OPS:
SELECT ps.slate_date, ps.player_name, ps.team, ps.ops_at_slate
FROM player_slate ps
JOIN label_event le
  ON le.slate_date = ps.slate_date AND le.mlb_id = ps.mlb_id
WHERE le.label_type = 'highest_value'
ORDER BY ps.ops_at_slate DESC;

-- Per-game runs vs Vegas O/U:
SELECT slate_date, home, away, vegas_total,
       home_score + away_score AS actual_runs,
       (home_score + away_score) - vegas_total AS over_under_delta
FROM slate_game
ORDER BY ABS((home_score + away_score) - vegas_total) DESC;

-- Wind direction × HR rate:
SELECT wind_dir_label, AVG(home_hr + away_hr) AS hr_per_game, COUNT(*)
FROM slate_game
GROUP BY wind_dir_label;
```

The `historical_slate_results.json` file is the most convenient
entry point if you don't want to deal with SQLite — every per-game
env field is in one nested document.

## Coverage gaps to be aware of

- 43 slates is a small sample. Quartile audits on individual signals
  produce ~10-20% noise bands; threshold-tuning needs out-of-sample
  validation before shipping.
- 5 of 273 pitcher rows in the at-slate stats backfill have unresolved
  names (scraper OCR errors); their `era_at_slate` / `whip_at_slate` /
  `k9_at_slate` are blank.
- The `player_alias` table is empty (0 rows). It only fills on demand
  when an HV box-score row's player name doesn't resolve cleanly.
- Some 2026 ABS-Challenge-System effects (umpire tendency compression)
  are not directly captured — umpire IDs were dropped from
  `slate_game` because the signal-to-storage ratio was too low under
  the new rules.

## File sizes

```
historical.db                       8.3 MB
historical_player_game_logs.csv     925 KB
historical_players.csv              212 KB
historical_slate_results.json       2.7 MB
historical_winning_drafts.csv       120 KB
hv_player_game_stats.csv             95 KB
```

Total uncompressed: ~12 MB. Zips well (mostly text + a SQLite file
that gzips down ~3-4×).
